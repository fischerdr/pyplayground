# Portworx Secret Migration Tools

A suite of Python scripts designed to facilitate the migration of Portworx volume encryption keys from HashiCorp Vault to Kubernetes Secrets. The tools provide export, checking, migration, and verification capabilities to ensure a smooth and auditable transition.

## Overview

The migration process follows a three-step workflow:

1. **Export** - Gather current PVC, PV, and Vault secret data
2. **Migrate** - Transfer encryption keys from Vault to Kubernetes Secrets
3. **Verify** - Confirm that the migration completed successfully

Additional utility scripts help with data gathering and validation throughout the process.

## Quick Start

### Prerequisites

- Python 3.9 or higher (up to 3.13)
- Kubernetes cluster access with appropriate permissions
- HashiCorp Vault access (for export phase)
- kubectl installed and configured

### Installation

1. **Clone or extract this repository:**
   ```bash
   cd pxsecretmigrate
   ```

2. **Create and activate virtual environment:**
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

### Basic Workflow

```bash
# Step 1: Export current state
python -m pxsecretmigrate.k8s_px_pvc_data_exporter --output-file production-cluster

# Step 2: (Optional) Check Vault secrets are accessible
python -m pxsecretmigrate.k8s_px_pvc_vault_secret_checker

# Step 3: Test migration with dry-run
python -m pxsecretmigrate.px_vault_to_k8s_secret_migrator \
  --input tmp/production-cluster_20231117_140530.json \
  --dry-run

# Step 4: Perform actual migration
python -m pxsecretmigrate.px_vault_to_k8s_secret_migrator \
  --input tmp/production-cluster_20231117_140530.json

# Step 5: Verify migration success
python -m pxsecretmigrate.verify_px_k8s_secret_migration \
  --input tmp/production-cluster_20231117_140530.json
```

## Scripts

### 1. k8s_px_pvc_data_exporter.py

**Purpose:** Exports Portworx PVC data including persistent volume information, Vault secret paths, volume labels, and encryption keys to a timestamped JSON file.

**Key Features:**
- Discovers PVCs with Vault secret annotations
- Retrieves encryption keys from Vault using service account authentication
- Executes `pxctl volume inspect` to gather Portworx volume labels
- Exports data to timestamped JSON files in `tmp/` directory

**Usage:**
```bash
# Export from current cluster context
python -m pxsecretmigrate.k8s_px_pvc_data_exporter

# Export with specific kubeconfig
python -m pxsecretmigrate.k8s_px_pvc_data_exporter --kubeconfig /path/to/kubeconfig

# Enable debug logging
python -m pxsecretmigrate.k8s_px_pvc_data_exporter --debug
```

### 2. k8s_px_pvc_vault_secret_checker.py

**Purpose:** Checks and validates Vault secrets referenced by Portworx PVC annotations.

**Usage:**
```bash
# Check all PVCs with default settings
python -m pxsecretmigrate.k8s_px_pvc_vault_secret_checker

# Show unmasked secret values
python -m pxsecretmigrate.k8s_px_pvc_vault_secret_checker --no-mask
```

### 3. k8s_px_volume_details.py

**Purpose:** Query Portworx PVs/PVCs and enrich with detailed `pxctl` inspection data.

**Usage:**
```bash
# Display volume details in console
python -m pxsecretmigrate.k8s_px_volume_details --kubeconfig /path/to/kubeconfig

# Export to JSON
python -m pxsecretmigrate.k8s_px_volume_details --kubeconfig /path/to/kubeconfig --format json

# Export to CSV
python -m pxsecretmigrate.k8s_px_volume_details --kubeconfig /path/to/kubeconfig --format csv
```

### 4. px_vault_to_k8s_secret_migrator.py

**Purpose:** Migrate Portworx volume encryption keys from HashiCorp Vault to Kubernetes Secrets.

**Usage:**
```bash
# Perform migration
python -m pxsecretmigrate.px_vault_to_k8s_secret_migrator --input /path/to/export.json

# Dry-run mode (simulate without changes)
python -m pxsecretmigrate.px_vault_to_k8s_secret_migrator --input /path/to/export.json --dry-run
```

### 5. verify_px_k8s_secret_migration.py

**Purpose:** Verify the migration of Portworx encryption keys from Vault to Kubernetes Secrets.

**Usage:**
```bash
# Verify migration
python -m pxsecretmigrate.verify_px_k8s_secret_migration --input /path/to/export.json
```

## Required Permissions

### Kubernetes
- Read access to PVs, PVCs, and StorageClasses
- Create/read access to Secrets
- Patch access to PVCs
- Exec access to Portworx pods

### Vault
- Read access to encryption key secrets
- Access to appropriate Vault namespaces
- Valid service account with Vault authentication

## Project Structure

```
pxsecretmigrate/
├── README.md                              # This file
├── CLAUDE.md                              # AI context and development notes
├── pyproject.toml                         # Python project configuration
├── requirements.txt                       # Python dependencies
├── .flake8                                # Flake8 linting configuration
├── pxsecretmigrate/                       # Main package directory
│   ├── __init__.py
│   ├── k8s_px_pvc_data_exporter.py       # Export PVC data from cluster
│   ├── k8s_px_pvc_vault_secret_checker.py # Validate Vault secrets
│   ├── k8s_px_volume_details.py          # Query volume details
│   ├── px_vault_to_k8s_secret_migrator.py # Perform migration
│   ├── verify_px_k8s_secret_migration.py # Verify migration
│   ├── README.md                          # Detailed script documentation
│   └── utils/                             # Shared utility modules
│       ├── __init__.py
│       ├── k8s_utils.py                  # Kubernetes utilities
│       ├── vault_utils.py                 # Vault utilities
│       ├── px_api.py                      # Portworx API utilities
│       ├── migration_utils.py             # Migration helpers
│       └── logging_utils.py               # Logging configuration
├── logs/                                  # Log files (generated)
└── tmp/                                   # Temporary files (generated)
```

## Development

### Code Standards

- Python 3.9+ required
- Type hints for all functions
- Google-style docstrings
- Black code formatting (line length 100)
- Flake8 linting
- Comprehensive logging

### Dependencies

Dependencies are managed through `pyproject.toml`. To update:

```bash
# Install pip-tools
pip install pip-tools

# Regenerate requirements.txt
pip-compile --resolver=backtracking -o requirements.txt pyproject.toml
```

## Logging

All scripts generate detailed logs in the `logs/` directory with timestamps:
- `logs/k8s_px_pvc_data_exporter_YYYYMMDD_HHMMSS.log`
- `logs/px_vault_to_k8s_secret_migrator_YYYYMMDD_HHMMSS.log`
- `logs/verify_px_k8s_secret_migration_YYYYMMDD_HHMMSS.log`

Enable debug logging with `--debug` flag for detailed troubleshooting.

## Common Issues

### Secret Name Normalization
Vault secret names may contain characters not allowed in Kubernetes secret names. The migration script automatically normalizes these names by:
- Converting to lowercase
- Replacing invalid characters with hyphens
- Ensuring names start and end with alphanumeric characters

### Authentication Failures
If Vault authentication fails:
- Verify service account has correct Vault role
- Check Vault credential secrets exist in Portworx namespace
- Ensure Vault is accessible from cluster network

### pxctl Command Timeouts
If pxctl commands timeout:
- Verify Portworx pods are running
- Check network connectivity to Portworx pods

## License

[Add appropriate license information]

## Contributing

[Add contribution guidelines]

## Support

For issues and questions, please refer to the detailed script documentation in [pxsecretmigrate/README.md](pxsecretmigrate/README.md).
