# Claude Code Context - Portworx Secret Migration Tools

This document provides context for AI assistants (like Claude) working on this codebase.

## Project Overview

This is a standalone Python package for migrating Portworx volume encryption keys from HashiCorp Vault to Kubernetes Secrets. It was extracted from a larger monorepo called `pyplayground`.

## Purpose

The tools in this repository help Kubernetes administrators migrate their Portworx encrypted volumes from using Vault-based encryption keys to Kubernetes Secret-based encryption keys. This is typically done to:
- Simplify key management
- Reduce external dependencies
- Improve security posture
- Align with Kubernetes-native secret management

## Architecture

### Core Components

1. **Export Tools** (`k8s_px_pvc_data_exporter.py`)
   - Connects to Kubernetes cluster
   - Identifies Portworx PVCs with Vault annotations
   - Retrieves encryption keys from Vault
   - Exports data to JSON for migration

2. **Validation Tools** (`k8s_px_pvc_vault_secret_checker.py`)
   - Validates Vault secret accessibility
   - Checks authentication status
   - Provides formatted output of secret status

3. **Migration Tools** (`px_vault_to_k8s_secret_migrator.py`)
   - Creates Kubernetes secrets from Vault data
   - Updates Portworx volume labels via `pxctl`
   - Updates PVC annotations
   - Removes Vault-related annotations

4. **Verification Tools** (`verify_px_k8s_secret_migration.py`)
   - Confirms secrets exist in Kubernetes
   - Validates volume labels are correct
   - Checks PVC annotations are updated
   - Generates verification reports

5. **Query Tools** (`k8s_px_volume_details.py`)
   - Provides detailed volume information
   - Supports multiple output formats (console, JSON, CSV)
   - Can process multiple clusters

### Utility Modules

Located in `pxsecretmigrate/utils/` directory:

- **k8s_utils.py**: Kubernetes client initialization, config loading, pod operations
- **vault_utils.py**: Vault client creation, authentication, secret retrieval
- **px_api.py**: Portworx-specific operations, pxctl command execution
- **migration_utils.py**: Secret name normalization, validation helpers
- **logging_utils.py**: Logging configuration and setup

## Key Technical Details

### Package Structure

```
pxsecretmigrate/
└── pxsecretmigrate/          # Main package
    ├── __init__.py
    ├── *.py                  # Migration scripts
    └── utils/                # Utility modules (nested)
        ├── __init__.py
        └── *.py
```

### Import Paths

All imports use the full package path:

```python
from pxsecretmigrate.utils.k8s_utils import get_k8s_client
from pxsecretmigrate.utils.vault_utils import create_vault_client
from pxsecretmigrate.utils.px_api import execute_pxctl_command
from pxsecretmigrate.utils.migration_utils import normalize_secret_name
from pxsecretmigrate.utils.logging_utils import setup_logging, get_logger
```

### Running Scripts

Scripts should be run as modules:

```bash
# Correct way
python -m pxsecretmigrate.k8s_px_pvc_data_exporter --help

# Alternative (if installed)
python pxsecretmigrate/k8s_px_pvc_data_exporter.py --help
```

### Dependencies

Core dependencies include:
- `click`: CLI framework
- `hvac`: HashiCorp Vault client
- `kubernetes`: Kubernetes API client
- `python-dotenv`: Environment variable management
- `pyyaml`: YAML configuration parsing
- `requests`: HTTP library
- `rich`: Terminal formatting and output

### Kubernetes Interactions

Scripts interact with Kubernetes through:
- Official Python Kubernetes client
- Exec into Portworx pods to run `pxctl` commands
- PVC annotation management
- Secret creation and validation

### Portworx Integration

- Uses `pxctl volume inspect` to get volume details
- Uses `pxctl volume update` to modify volume labels
- Requires exec access to Portworx pods in the cluster

### Vault Integration

- Service account-based authentication
- Supports Vault namespaces
- Reads encryption keys from configured paths
- Normalizes Vault paths for consistency

## Development Guidelines

### Code Style

- **Python Version**: 3.9 - 3.13
- **Formatting**: Black (line length 100)
- **Linting**: Flake8
- **Type Hints**: Required for all functions
- **Docstrings**: Google-style docstrings required

### Logging

- All scripts use structured logging via `logging_utils`
- Logs are written to `logs/` directory with timestamps
- Debug mode available via `--debug` flag
- Both file and console logging enabled

### Error Handling

- Comprehensive try-catch blocks for API calls
- Graceful handling of missing resources
- Detailed error messages for troubleshooting
- Exit codes indicate success/failure status

### Testing Approach

- Dry-run mode available for migration script
- Verification script confirms migration success
- Export data serves as audit trail
- Idempotent operations where possible

## Common Patterns

### CLI Structure

All scripts use Click for CLI:
```python
@click.command()
@click.option('--kubeconfig', help='Path to kubeconfig')
@click.option('--debug', is_flag=True, help='Enable debug logging')
def main(kubeconfig, debug):
    setup_logging(debug=debug)
    # ... rest of logic
```

### Kubernetes Client Setup

```python
from pxsecretmigrate.utils.k8s_utils import load_kube_config_auto, get_k8s_client

load_kube_config_auto(kubeconfig)
v1 = get_k8s_client()
```

### Portworx Command Execution

```python
from pxsecretmigrate.utils.px_api import execute_pxctl_command

result = execute_pxctl_command(
    v1, px_namespace, volume_id,
    ["volume", "inspect", volume_id]
)
```

### Secret Name Normalization

Secret names must comply with Kubernetes DNS-1123 subdomain rules:
- Lowercase alphanumeric characters, '-' or '.'
- Start and end with alphanumeric
- Max 253 characters

The `normalize_secret_name()` function in `migration_utils.py` handles this.

## Important Notes for AI Assistants

### When Making Changes

1. **Maintain backwards compatibility**: Export JSON format is critical
2. **Preserve logging**: Don't remove logging statements
3. **Keep dry-run mode**: Always test changes with `--dry-run`
4. **Update documentation**: Sync changes with README files
5. **Type safety**: Maintain type hints for all functions

### Common User Requests

1. **"Migration failed for some PVCs"**
   - Check logs in `logs/` directory
   - Verify permissions (RBAC, Vault access)
   - Check network connectivity to Portworx pods

2. **"Secret names are invalid"**
   - This is expected and handled automatically
   - Secret name normalization is intentional
   - Check `migration_utils.normalize_secret_name()`

3. **"How do I verify migration?"**
   - Use `verify_px_k8s_secret_migration.py`
   - Check the JSON verification report
   - Review exit code (0 = success, 1 = failures)

4. **"Can I run this multiple times?"**
   - Export: Yes, safe to run multiple times
   - Migration: Mostly idempotent, but may error on existing secrets
   - Verification: Yes, safe to run multiple times

### File Organization

```
pxsecretmigrate/
├── README.md                    # User-facing documentation
├── CLAUDE.md                    # This file - AI context
├── pyproject.toml               # Python package config
├── requirements.txt             # Locked dependencies
├── .flake8                      # Linting rules
├── pxsecretmigrate/            # Main package
│   ├── __init__.py
│   ├── README.md                # Detailed script docs
│   ├── *.py                     # Migration scripts
│   └── utils/                   # Utility modules (nested)
│       ├── __init__.py
│       └── *.py
├── logs/                        # Generated log files
└── tmp/                         # Generated temp files
```

### Dependencies Between Modules

```
Migration Scripts
    └── pxsecretmigrate.utils.k8s_utils
        └── pxsecretmigrate.utils.vault_utils
    └── pxsecretmigrate.utils.px_api
        └── pxsecretmigrate.utils.k8s_utils
    └── pxsecretmigrate.utils.migration_utils
    └── pxsecretmigrate.utils.logging_utils
```

## Known Limitations

1. **Requires cluster access**: Can't run offline
2. **Vault access needed**: For export phase only
3. **Portworx dependency**: Needs Portworx installed
4. **Single cluster**: Scripts process one cluster at a time (except k8s_px_volume_details.py)
5. **No rollback**: Migration is one-way (no built-in rollback)

## Future Enhancements

Potential areas for improvement:
- Multi-cluster migration support
- Rollback capability
- Parallel processing for large clusters
- Web UI for migration monitoring
- Prometheus metrics export
- Helm chart for deployment

## Troubleshooting Guide

### Common Errors

1. **"Failed to load kubeconfig"**
   - Check `--kubeconfig` path
   - Verify cluster context
   - Check network connectivity

2. **"Vault authentication failed"**
   - Verify service account exists
   - Check Vault role bindings
   - Validate Vault credentials in cluster

3. **"pxctl command timeout"**
   - Check Portworx pod status
   - Verify exec permissions
   - Check pod selector labels

4. **"Secret already exists"**
   - Expected if re-running migration
   - Use dry-run mode to test
   - Check for partial migrations

## Testing Recommendations

Before major changes:
1. Test with a small cluster (1-5 PVCs)
2. Always use `--dry-run` first
3. Verify with verification script
4. Check logs for warnings/errors
5. Test in non-production environment

## Version History

This is the initial standalone version extracted from `pyplayground` monorepo.

Original development context:
- Part of larger infrastructure automation toolkit
- Shared utility libraries with other tools
- Originally designed for specific enterprise use case

Standalone version changes:
- Extracted to independent repository
- Self-contained utility modules (nested under pxsecretmigrate/)
- Streamlined dependencies
- Standalone documentation
- Proper Python package structure

## Contact & Support

For issues, questions, or contributions:
- Check README.md for usage documentation
- Review logs/ directory for error details
- Refer to script-specific README in pxsecretmigrate/
